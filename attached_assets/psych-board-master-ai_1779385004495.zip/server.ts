import express from "express";
import path from "path";
import { GoogleGenAI, Type } from "@google/genai";
import { SEED_QUESTIONS } from "./src/data/seedQuestions";
import dotenv from "dotenv";

dotenv.config();

// Initialize express app
const app = express();
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

const PORT = 3000;

// Initialize GoogleGenAI client lazily (fails gracefully if API key is not present)
let genAIClient: GoogleGenAI | null = null;

function getGenAI(): GoogleGenAI {
  if (!genAIClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("GEMINI_API_KEY environment variable is not defined");
    }
    genAIClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return genAIClient;
}

// REST endpoints for AI generation

// Endpoint 1: Generate multiple-choice question
app.post("/api/generate-question", async (req, res) => {
  const { focusArea, source, fileData, fileMimeType, difficulty = "random", model } = req.body;
  const VALID_MODELS = [
    "gemini-3.5-flash",
    "gemini-3.1-pro-preview",
    "gemini-3.1-flash-lite",
    "gemini-flash-latest"
  ];
  const queryModel = typeof model === "string" && VALID_MODELS.includes(model) ? model : "gemini-3.5-flash";

  console.log(`[API] Received request for question generation. FocusArea: "${focusArea}", Source: "${source}", Difficulty: "${difficulty}", Model: "${queryModel}", HasFile: ${!!fileData}`);

  try {
    const ai = getGenAI();

    // Prepare custom instructions based on topic / focus area
    let focusInstructions = `The user is preparing for the Philippine board exam. Generate a highly realistic, challenging multiple-choice question. Focus area or instruction context is: "${focusArea || 'Comprehensive clinical psychology and assessment'}". If any document attachment or image is provided, parse and evaluate its diagnostic concepts, theories, and details to guide the items directly. Make sure the question tests real Philippine board curriculum concepts (such as DSM-5, psychometrics, I/O paradigms, developmental milestones).`;

    // Dynamic Difficulty Level Guidance
    if (difficulty === 'easy') {
      focusInstructions += `\n\nCRITICAL STRATIFICATION - EASY DIFFICULTY: The question must focus on standard, clear, and straightforward diagnostic criteria or definitions. Do NOT include confusing specifiers, complex overlapping exclusions, or tricky options. Keep it direct and core-diagnostic.`;
    } else if (difficulty === 'medium') {
      focusInstructions += `\n\nCRITICAL STRATIFICATION - MEDIUM DIFFICULTY: The question must focus on diagnostic criteria containing CONFUSING CLINICAL SPECIFIERS (e.g. 'with mixed features', 'with melancholic features', 'with atypical features', 'rapid cycling', 'with anxious distress', etc.). The vignette should test the student's fine-grained precision on specific subtypes or specifiers.`;
    } else if (difficulty === 'hard') {
      focusInstructions += `\n\nCRITICAL STRATIFICATION - HARD DIFFICULTY: The question must focus on diagnostic criteria but incorporate complex differential diagnosis, subtle exclusion rules, or include a "No diagnosis / criteria not met" option (the latter must be the correct answer in some cases). 
Example Scenario of No Diagnosis: A 23-year-old corporate worker presents for an assessment, reporting a 'constant dark cloud' over her life. She explains that since breaking up with her partner of three years four months ago, she has felt deeply sad, has had difficulty falling asleep most nights, and feels a lack of energy during her weekends. However, she notes that she still manages to perform exceptionally well at her new job, has not missed any deadlines, and continues to eat normally and hang out with her friends every Friday night. She denies any suicidal ideation, feelings of worthlessness, or psychomotor changes. Based on the DSM-5 diagnostic criteria, because her occupational/social/personal functioning remains outstanding and symptom/functional thresholds of any mental disorder are not met, the final correct answer is 'No diagnosis; the criteria for a mental disorder abnormality are not met'. Or generate a similarly challenging clinical boundary/differential.`;
    } else {
      // random
      focusInstructions += `\n\nCRITICAL STRATIFICATION - RANDOM DIFFICULTY: Select a random difficulty (easy, medium, or hard), and craft the question accordingly to maintain varying difficulty styles.`;
    }

    if (source === 'pharma') {
      focusInstructions += ` SPECIFIC REQUIREMENT: This is a PSYCHOPHARMACOLOGY question. The clinical vignette must describe a patient showing symptoms of a specific DSM-5 diagnostic category (e.g. ADHD, MDD, OCD, Schizophrenia, Panic) and end by asking what represents the FDA-approved first-line pharmacological treatment. Make sure options clearly include the first-line medication and realistic distractors (other classes or therapy types).`;
    } else if (source === 'assessment' && req.body.testDetails) {
      // Sourced from a specific psychological test (pmlepsychtests integration!)
      const test = req.body.testDetails;
      focusInstructions += ` SPECIFIC REQUIREMENT: This question must be specifically about the following psychological test:
- Name: "${test.name}"
- Developer: "${test.developer}"
- Purpose: "${test.purpose}"
- Scored as: "${test.scoring}"
- Interpretation threshold: "${test.interpretation}"
- Measuring: "${test.factorsMeasured}"
Ask about its age range, subscales, developer, scoring methodology, or ideal interpretation scenario based strictly on these details.`;
    } else if (source === 'io') {
      focusInstructions += ` SPECIFIC REQUIREMENT: Sourced from Industrial-Organizational Psychology (work motivation, selection metrics, HR policies, group dynamics, leadership).`;
    } else if (source === 'dev') {
      focusInstructions += ` SPECIFIC REQUIREMENT: Sourced from Developmental Psychology (psychosocial stages, cognitive developmental milestones, lifespan theories).`;
    }

    const systemPrompt = `You are a medical board examiner in psychiatry and psychology in the Philippines.
Generate a valid multiple choice test question. The vignette should be dense, diagnostic, and contextual.
Provide exactly 4 options. Specify the 0-indexed correct option.
Provide a clear high-yield explanation detailing why the correct option is correct and why the distractors are wrong.
Return a valid JSON object matching the requested schema.`;

    const contents: any[] = [focusInstructions];
    if (fileData && fileMimeType) {
      contents.push({
        inlineData: {
          mimeType: fileMimeType,
          data: fileData
        }
      });
    }

    const response = await ai.models.generateContent({
      model: queryModel,
      contents: contents,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            category: { 
              type: Type.STRING,
              description: "Short category name showing the clinical diagnostic area (e.g., DSM-5 — Neurodevelopmental, Psychopharmacology — OCD, Psychological Assessment)"
            },
            vignette: { 
              type: Type.STRING,
              description: "The full board-style clinical vignette or detailed descriptive question scenario." 
            },
            options: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Exactly four multiple-choice options."
            },
            correctIndex: { 
              type: Type.INTEGER, 
              description: "0-indexed index of the correct option (0, 1, 2, or 3)."
            },
            explanation: { 
              type: Type.STRING,
              description: "A comprehensive high-yield educational explanation detailing the diagnostic criteria, differentials, and correct answers."
            }
          },
          required: ["category", "vignette", "options", "correctIndex", "explanation"]
        }
      }
    });

    if (response.text) {
      const resultObj = JSON.parse(response.text.trim());
      return res.json(resultObj);
    } else {
      throw new Error("No response text returned from GenAI");
    }

  } catch (error: any) {
    console.warn("[API] Gemini generation failed, falling back to local seed bank. Error details:", error.message);
    
    // Fallback: Pick a relevant question from our high-yield seed questions bank
    let filtered = SEED_QUESTIONS;
    if (source) {
      filtered = SEED_QUESTIONS.filter(q => q.source === source);
    }
    
    if (difficulty && difficulty !== 'random') {
      const diffMatched = filtered.filter(q => q.difficulty === difficulty);
      if (diffMatched.length > 0) {
        filtered = diffMatched;
      }
    }

    if (filtered.length === 0) {
      filtered = SEED_QUESTIONS;
    }
    
    // Pick unique index
    const randomIdx = Math.floor(Math.random() * filtered.length);
    const fallbackQuestion = filtered[randomIdx];
    
    return res.json({
      ...fallbackQuestion,
      isFallback: true,
      fallbackMessage: "Utilized local seed question bank (AI API key not configured or rate-limited)"
    });
  }
});

// Endpoint 2: Generate mnemonic
app.post("/api/generate-mnemonic", async (req, res) => {
  const { explanation, vignette, model } = req.body;
  if (!explanation) {
    return res.status(400).json({ error: "Missing explanation text for mnemonic creation." });
  }

  const VALID_MODELS = [
    "gemini-3.5-flash",
    "gemini-3.1-pro-preview",
    "gemini-3.1-flash-lite",
    "gemini-flash-latest"
  ];
  const queryModel = typeof model === "string" && VALID_MODELS.includes(model) ? model : "gemini-3.5-flash";

  try {
    const ai = getGenAI();
    const prompt = `Create a high-yield psychological, diagnostic, or psychopharmacological mnemonic for this diagnostic scenario.
Scenario context: "${vignette || 'Clinical Assessment'}"
Concept explanation: "${explanation}"

Provide a creative, memorable word-acronym (e.g., SIGECAPS) or phrase, and clearly map each letter to a diagnostic criteria or recall item in a list format. Keep it concise, memorable, and educational.`;

    const response = await ai.models.generateContent({
      model: queryModel,
      contents: prompt,
      config: {
        systemInstruction: "You are a master of mnemonic study techniques for medical and psychological board review.",
      }
    });

    res.json({ mnemonic: response.text });
  } catch (error: any) {
    console.warn("[API] Gemini mnemonic generation failed.", error.message);
    // Standard high-quality local fallback mnemonics
    res.json({ 
      mnemonic: `**FALLBACK MNEMONIC: S-M-A-R-T**\n\n*   **S**ymptom review: Track standard clinical indexes daily.\n*   **M**ental status: Assess appearance, mood, affect, and raw thoughts.\n*   **A**lliance build: Guarantee secure therapeutic bond.\n*   **R**oot cause: Exclude secondary substances or physical ailments.\n*   **T**reatment: Pair evidence-based psychotherapeutic and pharmacological protocols.`,
      isFallback: true 
    });
  }
});

// Endpoint 3: Submit reviewee feedback
app.post("/api/submit-feedback", (req, res) => {
  const { email, topic, rating, message } = req.body;
  console.log(`[FEEDBACK] Secure feedback registry: ${email}. Topic: ${topic}, Rating: ${rating}/5, Msg: "${message}"`);
  
  if (!email || !message) {
    return res.status(400).json({ error: "Required feedback parameters are missing." });
  }

  res.json({ 
    success: true, 
    message: `💚 Secure receipt confirmed! Your digital feedback concerning topic category "${topic}" has been registered in the BoardPassPH examiner system. Directors will monitor or action this immediately.`
  });
});

// Export app for serverless deployment
export default app;

// Integrate Vite middleware or serve static files in production
async function startServer() {
  const isVercel = !!process.env.VERCEL || !!process.env.NOW_BUILDER || !!process.env.AWS_LAMBDA_FUNCTION_NAME || !!process.env.VERCEL_ENV;
  if (isVercel) {
    console.log("[Server] Running in Vercel Serverless environment. Listen skipped.");
    return;
  }

  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("[Vite] Development environment detected: Mounted Vite middleware.");
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log("[Production] Mounted static router for built React elements.");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Server] BoardPassPH engine initialized successfully.`);
    console.log(`[Host] Listening at http://localhost:${PORT}`);
  });
}

startServer();
