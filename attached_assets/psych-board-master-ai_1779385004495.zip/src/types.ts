export interface TestAdministration {
  type: string;
  items: string;
  ageRange: string;
  time: string;
  trainingNeeded: string;
}

export interface PsychologyTest {
  id: string;
  name: string;
  category: string;
  developer: string;
  quickInfo: string;
  purpose: string;
  administration: TestAdministration;
  scoring: string;
  interpretation: string;
  mnemonics?: string;
  versions: string;
  factorsMeasured: string;
}

export interface Category {
  id: string;
  name: string;
  description: string;
}

export interface Question {
  id?: string;
  category: string;
  vignette: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  // Metadata for filtering / diagnostic feedback
  source?: 'dsm5' | 'pharma' | 'assessment' | 'dev' | 'io' | 'local_test';
  testId?: string; // If sourced from a specific psychological test
  difficulty?: 'easy' | 'medium' | 'hard' | 'random';
}

export interface UserProfile {
  email: string;
  tier: 'Free' | 'Pro' | 'Clinical' | 'Clinical Trial';
  totalXp: number;
  streak: number;
  streakShields: number;
  lastDate: string; // YYYY-MM-DD format
  currentCombo: number;
  attempts: number;
  correct: number;
  adaptive: boolean;
  deck: Question[]; // Spaced repetition missed questions
  notes: Record<string, string>; // Base64 encoded vignette snippet -> personal notes
  heat: Record<string, number>; // Date -> question attempts count
  badges: Record<string, boolean>; // BadgeId -> unlocked
  theme?: string;
  password?: string;
  passwordHint?: string;
  signUpDate?: string; // YYYY-MM-DD format for trial computation
  moods?: Record<string, string>; // Date (YYYY-MM-DD) -> Mood ID ('motivated', 'calm', 'anxious', 'tired', 'sad')
  habitsChecked?: Record<string, Record<string, boolean>>; // Date (YYYY-MM-DD) -> HabitId -> boolean
  calendarEvents?: Record<string, { id: string; title: string; note?: string; color: string }[]>; // Date (YYYY-MM-DD) -> array of events
  dailyChallenges?: Record<string, 'correct' | 'incorrect'>; // Date (YYYY-MM-DD) -> completion status
}

export interface ExamQuestionState {
  question: Question;
  selectedAnswer: number | null;
  flagged: boolean;
}

export interface MockExamState {
  questions: ExamQuestionState[];
  currentQuestionIndex: number;
  secondsRemaining: number;
  isActive: boolean;
  isCompleted: boolean;
  focusArea: string;
  score: number;
  gainedXp: number;
}
